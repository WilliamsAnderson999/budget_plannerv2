import 'package:budget_manager/screens/add_transaction_screen.dart';
import 'package:flutter/material.dart';
import 'package:budget_manager/screens/home_screen.dart';
import 'package:budget_manager/screens/analysis_screen.dart';
import 'package:budget_manager/screens/transactions_screen.dart';
import 'package:budget_manager/screens/dashboard_screen.dart';
import 'package:budget_manager/screens/profile_screen.dart';
import 'package:budget_manager/theme/app_theme.dart';

class App extends StatefulWidget {
  const App({super.key});

  @override
  State<App> createState() => _AppState();
}

class _AppState extends State<App> {
  int _selectedIndex = 0;

  final List<Widget> _screens = [
    const HomeScreen(),
    const AnalysisScreen(),
    const TransactionsScreen(),
    const DashboardScreen(),
    const ProfileScreen(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _selectedIndex,
        children: _screens,
      ),
      bottomNavigationBar: _buildBottomNavigationBar(),
      floatingActionButton: _selectedIndex == 2
          ? FloatingActionButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const AddTransactionScreen()),
                );
              },
              backgroundColor: AppTheme.accentBronze,
              foregroundColor: AppTheme.primaryBlack,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Icon(Icons.add, size: 28),
            )
          : null,
    );
  }

  Widget _buildBottomNavigationBar() {
  return DecoratedBox(
    decoration: BoxDecoration(
      color: AppTheme.surfaceBlack,
      border: const Border(
        top: BorderSide(
          color: AppTheme.outlineColor,
          width: 1,
        ),
      ),
      boxShadow: [
        BoxShadow(
          // ignore: deprecated_member_use
          color: Colors.black.withOpacity(0.30),
          blurRadius: 20,
          offset: const Offset(0, -2),
        ),
      ],
    ),
    child: NavigationBar(
      selectedIndex: _selectedIndex,
      onDestinationSelected: _onItemTapped,
      backgroundColor: AppTheme.surfaceBlack,
      indicatorColor: AppTheme.accentBronze.withOpacity(0.18),
      destinations: const [
        NavigationDestination(
          icon: Icon(Icons.home_outlined),
          selectedIcon: Icon(Icons.home_filled),
          label: 'Accueil',
        ),
        NavigationDestination(
          icon: Icon(Icons.analytics_outlined),
          selectedIcon: Icon(Icons.analytics),
          label: 'Analyse',
        ),
        NavigationDestination(
          icon: Icon(Icons.swap_horiz_outlined),
          selectedIcon: Icon(Icons.swap_horiz),
          label: 'Transactions',
        ),
        NavigationDestination(
          icon: Icon(Icons.calendar_today_outlined),
          selectedIcon: Icon(Icons.calendar_today),
          label: 'Dashboard',
        ),
        NavigationDestination(
          icon: Icon(Icons.person_outlined),
          selectedIcon: Icon(Icons.person),
          label: 'Profil',
        ),
      ],
    ),
  );
}

}
