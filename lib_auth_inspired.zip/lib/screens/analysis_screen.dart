import 'package:flutter/material.dart';
import 'package:budget_manager/widgets/period_selector.dart';
import 'package:budget_manager/widgets/analytics_chart.dart';
import 'package:budget_manager/widgets/budget_progress.dart';
import 'package:budget_manager/widgets/ai_chat_dialog.dart';
import 'package:budget_manager/models/goal.dart';
import 'package:budget_manager/theme/app_theme.dart';
import 'package:provider/provider.dart';
import 'package:budget_manager/services/auth_service.dart';
import 'package:budget_manager/services/firestore_service.dart';
import 'package:budget_manager/services/transaction_service.dart';

class AnalysisScreen extends StatefulWidget {
  const AnalysisScreen({super.key});

  @override
  State<AnalysisScreen> createState() => _AnalysisScreenState();
}

class _AnalysisScreenState extends State<AnalysisScreen> {
  String _selectedPeriod = 'Mensuel';
  final List<String> _periods = [
    'Quotidien',
    'Hebdomadaire',
    'Mensuel',
    'Annuel'
  ];

  double totalBalance = 0;
  double totalExpense = 0;
  double totalIncome = 0;
  double previousBalance = 0; // For change calculation
  List<ChartData> chartData = [];
  Map<String, dynamic> categoryExpenses = {};
  List<Goal> _goals = [];

  @override
  void initState() {
    super.initState();
    _loadGoals();
  }

  void _loadGoals() async {
    final authService = Provider.of<AuthService>(context, listen: false);
    final firestoreService =
        Provider.of<FirestoreService>(context, listen: false);
    final userId = authService.currentUser!.uid;
    final goals = await firestoreService.getGoals(userId);
    setState(() {
      _goals = goals;
    });
  }

  void _loadData() {
    _loadGoals();
    // Add any other data loading logic here if needed
  }

  void _onPeriodChanged(String period) {
    setState(() {
      _selectedPeriod = period;
    });
    _loadData(); // Reload data for new period
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<TransactionService>(
        builder: (context, transactionService, child) {
      final transactions = transactionService.transactions;
      final currentTotalBalance = transactions
              .where((t) => !t.isExpense)
              .fold(0.0, (sum, t) => sum + t.amount) -
          transactions
              .where((t) => t.isExpense)
              .fold(0.0, (sum, t) => sum + t.amount);
      final currentTotalExpense = transactions
          .where((t) => t.isExpense)
          .fold(0.0, (sum, t) => sum + t.amount);
      final currentTotalIncome = transactions
          .where((t) => !t.isExpense)
          .fold(0.0, (sum, t) => sum + t.amount);
      final currentChartData = _getChartDataFromTransactions(transactions);
      final currentCategoryExpenses = _calculateCategoryExpenses(transactions);

      return Scaffold(
        body: CustomScrollView(
          slivers: [
            SliverAppBar(
              pinned: true,
              floating: true,
              backgroundColor: AppTheme.surfaceBlack,
              title: Text(
                'Analyse Financière',
                style: Theme.of(context).textTheme.headlineMedium,
              ),
              actions: [
                IconButton(
                  icon: const Icon(Icons.filter_alt_outlined),
                  onPressed: () {
                    _showFilterDialog();
                  },
                  color: AppTheme.accentGold,
                ),
              ],
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    // Sélecteur de période
                    PeriodSelector(
                      periods: _periods,
                      selectedPeriod: _selectedPeriod,
                      onPeriodChanged: _onPeriodChanged,
                    ),

                    const SizedBox(height: 24),

                    // Statistiques principales
                    _buildStatsCards(currentTotalBalance, currentTotalIncome,
                        currentTotalExpense),

                    const SizedBox(height: 24),

                    // Graphique des revenus/dépenses
                    _buildIncomeExpenseChart(currentChartData,
                        currentTotalIncome, currentTotalExpense),

                    const SizedBox(height: 24),

                    // Progression des objectifs (kept hardcoded as per your project)
                    _buildGoalsSection(),

                    const SizedBox(height: 24),

                    // Analyse par catégorie
                    _buildCategoryAnalysis(currentCategoryExpenses),
                  ],
                ),
              ),
            ),
          ],
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: _showAIChat,
          backgroundColor: AppTheme.accentBronze,
          child: const Icon(Icons.smart_toy),
        ),
      );
    });
  }

  Widget _buildStatsCards(double balance, double income, double expense) {
    final balanceChange = previousBalance > 0
        ? ((balance - previousBalance) / previousBalance * 100)
            .toStringAsFixed(1)
        : '0.0';
    return Row(
      children: [
        Expanded(
          child: _buildStatCard(
            title: 'Solde Total',
            value: '\$${balance.toStringAsFixed(2)}',
            icon: Icons.account_balance_wallet_outlined,
            color: AppTheme.accentGold,
            change:
                '${double.parse(balanceChange) >= 0 ? '+' : ''}$balanceChange%',
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _buildStatCard(
            title: 'Dépenses Totales',
            value: '\$${expense.toStringAsFixed(2)}',
            icon: Icons.trending_down_outlined,
            color: AppTheme.expenseColor,
            change: '-5.2%', // Placeholder; calculate if needed
          ),
        ),
      ],
    );
  }

  Widget _buildStatCard({
    required String title,
    required String value,
    required IconData icon,
    required Color color,
    required String change,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.cardBlack,
        borderRadius: BorderRadius.circular(AppTheme.borderRadiusLarge),
        boxShadow: AppTheme.cardShadow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  // ignore: deprecated_member_use
                  color: color.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: color, size: 24),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: change.startsWith('+')
                      // ignore: deprecated_member_use
                      ? AppTheme.successColor.withOpacity(0.15)
                      // ignore: deprecated_member_use
                      : AppTheme.errorColor.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  change,
                  style: TextStyle(
                    color: change.startsWith('+')
                        ? AppTheme.successColor
                        : AppTheme.errorColor,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            title,
            style: Theme.of(context).textTheme.titleSmall,
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: Theme.of(context).textTheme.headlineSmall!.copyWith(
                  fontSize: 22,
                ),
          ),
        ],
      ),
    );
  }

  Widget _buildIncomeExpenseChart(
      List<ChartData> data, double income, double expense) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.cardBlack,
        borderRadius: BorderRadius.circular(AppTheme.borderRadiusLarge),
        boxShadow: AppTheme.cardShadow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Revenus & Dépenses',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 200,
            child: AnalyticsChart(
              period: _selectedPeriod,
              data: data,
            ),
          ),
          const SizedBox(height: 16),
          _buildChartLegend(income, expense),
        ],
      ),
    );
  }

  Widget _buildChartLegend(double income, double expense) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        _buildLegendItem(
          color: AppTheme.incomeColor,
          label: 'Revenus',
          value: '\$${income.toStringAsFixed(2)}',
        ),
        _buildLegendItem(
          color: AppTheme.expenseColor,
          label: 'Dépenses',
          value: '\$${expense.toStringAsFixed(2)}',
        ),
      ],
    );
  }

  Widget _buildLegendItem({
    required Color color,
    required String label,
    required String value,
  }) {
    return Column(
      children: [
        Row(
          children: [
            Container(
              width: 12,
              height: 12,
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(3),
              ),
            ),
            const SizedBox(width: 8),
            Text(
              label,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ],
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: Theme.of(context).textTheme.titleMedium,
        ),
      ],
    );
  }

  Widget _buildGoalsSection() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.cardBlack,
        borderRadius: BorderRadius.circular(AppTheme.borderRadiusLarge),
        boxShadow: AppTheme.cardShadow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Mes Objectifs',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 16),
          ..._goals.map((goal) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: BudgetProgress(
                  title: goal.name,
                  currentAmount: goal.currentAmount,
                  targetAmount: goal.targetAmount,
                  color: Colors.blue, // or random
                  icon: Icons.savings,
                ),
              )),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            onPressed: _addGoal,
            icon: const Icon(Icons.add),
            label: const Text('Ajouter un objectif'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.accentBronze,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryAnalysis(Map<String, dynamic> categories) {
    final totalExpenseForPeriod =
        categories.values.fold(0.0, (sum, amount) => sum + amount);
    final categoryList = categories.entries.map((entry) {
      final percentage = totalExpenseForPeriod > 0
          ? (entry.value / totalExpenseForPeriod * 100).round()
          : 0;
      return {
        'name': entry.key,
        'amount': entry.value,
        'percentage': percentage,
        'color': _getColorForCategory(entry.key),
      };
    }).toList();

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.cardBlack,
        borderRadius: BorderRadius.circular(AppTheme.borderRadiusLarge),
        boxShadow: AppTheme.cardShadow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Analyse par Catégorie',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 16),
          ...categoryList.map((category) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Row(
                children: [
                  Container(
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: category['color'] as Color,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      category['name'] as String,
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ),
                  Text(
                    '\$${(category['amount'] as double).toStringAsFixed(2)}',
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                  const SizedBox(width: 12),
                  SizedBox(
                    width: 80,
                    child: LinearProgressIndicator(
                      value: (category['percentage'] as int) / 100,
                      backgroundColor: AppTheme.surfaceBlack,
                      color: category['color'] as Color,
                      minHeight: 6,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    '${category['percentage']}%',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }

  List<ChartData> _getChartDataFromTransactions(List transactions) {
    // Group by week for the last 4 weeks
    final now = DateTime.now();
    final weeks = <String, Map<String, double>>{};
    for (int i = 0; i < 4; i++) {
      final weekStart = now.subtract(Duration(days: now.weekday - 1 + (i * 7)));
      final weekEnd = weekStart.add(const Duration(days: 6));
      final label = '${weekStart.day}/${weekStart.month}';
      weeks[label] = {'income': 0, 'expense': 0};
      for (var t in transactions) {
        if (t.date.isAfter(weekStart.subtract(const Duration(days: 1))) &&
            t.date.isBefore(weekEnd.add(const Duration(days: 1)))) {
          if (t.isExpense) {
            weeks[label]!['expense'] = weeks[label]!['expense']! + t.amount;
          } else {
            weeks[label]!['income'] = weeks[label]!['income']! + t.amount;
          }
        }
      }
    }
    return weeks.entries
        .map((e) => ChartData(e.key, e.value['income']!, e.value['expense']!))
        .toList();
  }

  Map<String, dynamic> _calculateCategoryExpenses(List transactions) {
    final Map<String, double> categories = {};
    for (var t in transactions) {
      if (t.isExpense) {
        categories[t.category] = (categories[t.category] ?? 0) + t.amount;
      }
    }
    return categories;
  }

  Color _getColorForCategory(String category) {
    switch (category.toLowerCase()) {
      case 'alimentation':
      case 'food':
        return Colors.orange;
      case 'transport':
        return Colors.blue;
      case 'shopping':
        return Colors.purple;
      case 'santé':
      case 'health':
        return Colors.green;
      case 'divertissement':
      case 'entertainment':
        return Colors.pink;
      default:
        return Colors.grey;
    }
  }

  void _showAIChat() {
    showDialog(
      context: context,
      builder: (context) => const AIChatDialog(),
    );
  }

  void _showFilterDialog() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: AppTheme.cardBlack,
          title: Text(
            'Filtres',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildFilterOption('Toutes les catégories', true),
              _buildFilterOption('Revenus seulement', false),
              _buildFilterOption('Dépenses seulement', false),
              _buildFilterOption('Par montant', false),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Annuler'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.accentBronze,
              ),
              child: const Text('Appliquer'),
            ),
          ],
        );
      },
    );
  }

  Widget _buildFilterOption(String label, bool selected) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Checkbox(
            value: selected,
            onChanged: (value) {},
            activeColor: AppTheme.accentBronze,
            checkColor: AppTheme.primaryBlack,
          ),
          Text(
            label,
            style: Theme.of(context).textTheme.bodyMedium,
          ),
        ],
      ),
    );
  }

  void _addGoal() {
    print('Add goal button pressed');
    final nameController = TextEditingController();
    final targetController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: AppTheme.cardBlack,
          title: Text(
            'Ajouter un objectif',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                decoration: const InputDecoration(
                  labelText: 'Nom de l\'objectif',
                  hintText: 'Ex: Voyage en Europe',
                ),
                style: TextStyle(color: Colors.white),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: targetController,
                decoration: const InputDecoration(
                  labelText: 'Montant cible (€)',
                  hintText: 'Ex: 5000',
                ),
                keyboardType: TextInputType.number,
                style: TextStyle(color: Colors.white),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Annuler'),
            ),
            ElevatedButton(
              onPressed: () async {
                final name = nameController.text.trim();
                final target = double.tryParse(targetController.text) ?? 0;

                if (name.isNotEmpty && target > 0) {
                  final authService =
                      Provider.of<AuthService>(context, listen: false);
                  final firestoreService =
                      Provider.of<FirestoreService>(context, listen: false);
                  final userId = authService.currentUser!.uid;
                  print('userId: $userId');
                  final goal = Goal(
                    id: DateTime.now().millisecondsSinceEpoch.toString(),
                    name: name,
                    targetAmount: target,
                    currentAmount: 0,
                    userId: userId,
                    createdAt: DateTime.now(),
                  );

                  try {
                    await firestoreService.addGoal(goal);
                    print('Goal added successfully');
                    _loadData(); // Reload to show new goal
                    Navigator.pop(context);
                  } catch (e) {
                    print('Error adding goal: $e');
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                          content: Text(
                              'Erreur lors de l\'ajout de l\'objectif: $e')),
                    );
                  }
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.accentBronze,
              ),
              child: const Text('Ajouter'),
            ),
          ],
        );
      },
    );
  }
}
