import 'package:flutter/material.dart';
import 'package:budget_manager/widgets/balance_card.dart';
import 'package:budget_manager/widgets/transaction_item.dart';
import 'package:budget_manager/widgets/category_chip.dart';
import 'package:budget_manager/theme/app_theme.dart';
import 'package:provider/provider.dart';
import 'package:budget_manager/services/auth_service.dart';
import 'package:budget_manager/services/transaction_service.dart';
import 'package:budget_manager/models/transaction.dart' as budget_transaction;
import 'package:budget_manager/screens/transactions_screen.dart';
import 'package:budget_manager/screens/search_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  double monthlyBudget = 20000.00; // Fetch from Firestore if stored
  List<budget_transaction.Transaction> recentTransactions = [];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final authService = Provider.of<AuthService>(context, listen: false);
      final transactionService =
          Provider.of<TransactionService>(context, listen: false);
      if (authService.currentUser != null) {
        transactionService.fetchTransactions(authService.currentUser!.uid);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isSmallScreen = screenWidth < 600;

    return CustomScrollView(
      slivers: [
        // AppBar personnalisé
        SliverAppBar(
          expandedHeight: 100,
          floating: true,
          pinned: true,
          backgroundColor: AppTheme.surfaceBlack,
          flexibleSpace: FlexibleSpaceBar(
            titlePadding: const EdgeInsets.only(left: 20, bottom: 16),
            title: FittedBox(
              fit: BoxFit.scaleDown,
              alignment: Alignment.bottomLeft,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Bonjour, ${Provider.of<AuthService>(context).currentUser?.displayName ?? 'Utilisateur'}',
                    style: Theme.of(context).textTheme.titleSmall,
                  ),
                  const SizedBox(height: 3),
                  Text(
                    'Gérez vos dépenses aisément',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                ],
              ),
            ),
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.notifications_outlined),
              onPressed: () {},
              color: AppTheme.accentGold,
            ),
            IconButton(
              icon: const Icon(Icons.search),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const SearchScreen()),
                );
              },
              color: AppTheme.accentGold,
            ),
          ],
        ),

        // Contenu principal
        SliverToBoxAdapter(child: Consumer<TransactionService>(
          builder: (context, transactionService, child) {
            // Calculate totals
            final transactions = transactionService.transactions;
            final totalIncome = transactions
                .where((t) => !t.isExpense)
                .fold(0.0, (sum, t) => sum + t.amount);
            final totalExpense = transactions
                .where((t) => t.isExpense)
                .fold(0.0, (sum, t) => sum + t.amount);
            final totalBalance = totalIncome - totalExpense;

            // Category expenses
            final categoryExpenses = <String, double>{};
            for (var t in transactions.where((t) => t.isExpense)) {
              categoryExpenses[t.category] =
                  (categoryExpenses[t.category] ?? 0) + t.amount;
            }

            // Recent transactions
            recentTransactions = transactions
                .where((t) => t.date
                    .isAfter(DateTime.now().subtract(const Duration(days: 30))))
                .toList()
              ..sort((a, b) => b.date.compareTo(a.date));
            recentTransactions = recentTransactions.take(5).toList();

            return Padding(
              padding: EdgeInsets.all(isSmallScreen ? 8.0 : 16.0),
              child: Column(
                children: [
                  // Carte de solde
                  BalanceCard(
                    totalBalance: totalBalance,
                    totalExpense: totalExpense,
                    monthlyBudget: monthlyBudget,
                    expensePercentage:
                        ((totalExpense / monthlyBudget * 100).clamp(0.0, 100.0))
                            .toInt(),
                  ),

                  SizedBox(height: isSmallScreen ? 16 : 24),

                  // Statistiques rapides
                  _buildQuickStats(context, totalIncome, totalExpense),
                  SizedBox(height: isSmallScreen ? 16 : 24),

                  // Catégories fréquentes
                  _buildCategoriesSection(context, categoryExpenses),
                  SizedBox(height: isSmallScreen ? 16 : 24),
                  // Transactions récentes
                  _buildRecentTransactions(context),
                ],
              ),
            );
          },
        )),
      ],
    );
  }

  Widget _buildQuickStats(
      BuildContext context, double totalIncome, double totalExpense) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isSmallScreen = screenWidth < 600;

    final weeklyIncome = totalIncome * 7 / 30; // Approximate weekly
    final weeklyExpense = totalExpense * 7 / 30;

    return Row(
      children: [
        Expanded(
          child: _buildStatCard(
            context,
            title: 'Revenu Hebdo',
            value: '\$${weeklyIncome.toStringAsFixed(2)}',
            change: '+12%',
            color: AppTheme.incomeColor,
            icon: Icons.arrow_upward,
          ),
        ),
        SizedBox(width: isSmallScreen ? 8 : 12),
        Expanded(
          child: _buildStatCard(
            context,
            title: 'Dépenses Hebdo',
            value: '\$${weeklyExpense.toStringAsFixed(2)}',
            change: '-5%',
            color: AppTheme.expenseColor,
            icon: Icons.arrow_downward,
          ),
        ),
      ],
    );
  }

  Widget _buildStatCard(
    BuildContext context, {
    required String title,
    required String value,
    required String change,
    required Color color,
    required IconData icon,
  }) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isSmallScreen = screenWidth < 600;

    return Container(
      padding: EdgeInsets.all(isSmallScreen ? 12 : 16),
      decoration: BoxDecoration(
        color: AppTheme.cardBlack,
        borderRadius: BorderRadius.circular(AppTheme.borderRadiusLarge),
        boxShadow: AppTheme.cardShadow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.15),
                  shape: BoxShape.circle,
                ),
                child: Icon(icon, color: color, size: isSmallScreen ? 18 : 20),
              ),
              const Spacer(),
              Text(
                change,
                style: TextStyle(
                  color: change.startsWith('+')
                      ? AppTheme.successColor
                      : AppTheme.errorColor,
                  fontSize: isSmallScreen ? 10 : 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          SizedBox(height: isSmallScreen ? 8 : 12),
          Text(title,
              style: Theme.of(context)
                  .textTheme
                  .titleSmall
                  ?.copyWith(fontSize: isSmallScreen ? 12 : 14)),
          SizedBox(height: isSmallScreen ? 4 : 8),
          Text(
            value,
            style: Theme.of(context)
                .textTheme
                .headlineSmall
                ?.copyWith(fontSize: isSmallScreen ? 18 : 22),
          ),
        ],
      ),
    );
  }

  Widget _buildCategoriesSection(
      BuildContext context, Map<String, double> categoryExpenses) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isSmallScreen = screenWidth < 600;

    final topCategories = categoryExpenses.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Catégories Populaires',
          style: Theme.of(context)
              .textTheme
              .titleLarge
              ?.copyWith(fontSize: isSmallScreen ? 16 : 18),
        ),
        SizedBox(height: isSmallScreen ? 8 : 12),
        SizedBox(
          height: isSmallScreen ? 60 : 80,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: topCategories.map((entry) {
              return Padding(
                padding: EdgeInsets.only(right: isSmallScreen ? 8 : 12),
                child: CategoryChip(
                  icon: _getIconForCategory(entry.key),
                  label: entry.key,
                  amount: entry.value,
                  color: _getColorForCategory(entry.key),
                ),
              );
            }).toList(),
          ),
        ),
      ],
    );
  }

  Widget _buildRecentTransactions(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isSmallScreen = screenWidth < 600;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Transactions Récentes',
              style: Theme.of(context)
                  .textTheme
                  .titleLarge
                  ?.copyWith(fontSize: isSmallScreen ? 16 : 18),
            ),
            TextButton(
              onPressed: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const TransactionsScreen()));
              },
              child: Text(
                'Tout voir',
                style: TextStyle(
                  color: AppTheme.accentGold,
                  fontWeight: FontWeight.w600,
                  fontSize: isSmallScreen ? 12 : 14,
                ),
              ),
            ),
          ],
        ),
        SizedBox(height: isSmallScreen ? 8 : 12),
        ...recentTransactions.map((transaction) {
          return Padding(
            padding: EdgeInsets.only(bottom: isSmallScreen ? 8 : 12),
            child: TransactionItem(
              title: transaction.title,
              subtitle:
                  '${transaction.date.hour}:${transaction.date.minute.toString().padLeft(2, '0')} - ${transaction.date.day} ${transaction.date.month} | ${transaction.category}',
              category: transaction.category,
              amount: transaction.amount,
              isExpense: transaction.isExpense,
              icon: _getIconForCategory(transaction.category),
            ),
          );
        }),
      ],
    );
  }

  IconData _getIconForCategory(String category) {
    switch (category.toLowerCase()) {
      case 'salaire':
      case 'income':
        return Icons.account_balance_wallet_outlined;
      case 'alimentation':
      case 'food':
        return Icons.shopping_cart_outlined;
      case 'loyer':
      case 'rent':
        return Icons.home_outlined;
      case 'transport':
        return Icons.directions_car_outlined;
      case 'restaurant':
        return Icons.restaurant_outlined;
      case 'travail':
      case 'work':
        return Icons.computer_outlined;
      case 'divertissement':
      case 'entertainment':
        return Icons.movie_outlined;
      default:
        return Icons.attach_money_outlined;
    }
  }

  Color _getColorForCategory(String category) {
    switch (category.toLowerCase()) {
      case 'alimentation':
      case 'food':
        return Colors.orange;
      case 'transport':
        return Colors.blue;
      case 'shopping':
        return Colors.purple;
      case 'santé':
      case 'health':
        return Colors.green;
      default:
        return Colors.grey;
    }
  }
}
