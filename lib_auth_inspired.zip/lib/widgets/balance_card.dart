import 'package:flutter/material.dart';
import 'package:percent_indicator/percent_indicator.dart';
import 'package:budget_manager/theme/app_theme.dart';

class BalanceCard extends StatelessWidget {
  final double totalBalance;
  final double totalExpense;
  final double monthlyBudget;
  final int expensePercentage;

  const BalanceCard({
    super.key,
    required this.totalBalance,
    required this.totalExpense,
    required this.monthlyBudget,
    required this.expensePercentage,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: AppTheme.bronzeGradient,
        borderRadius: BorderRadius.circular(AppTheme.borderRadiusXLarge),
        boxShadow: [
          BoxShadow(
            color: AppTheme.accentBronze.withOpacity(0.3),
            blurRadius: 25,
            spreadRadius: 1,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        children: [
          // En-tête
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Solde Total',
                style: TextStyle(
                  color: AppTheme.primaryBlack,
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                ),
              ),
              IconButton(
                icon: Icon(Icons.more_vert, color: AppTheme.primaryBlack),
                onPressed: () {},
              ),
            ],
          ),

          // Montant total
          Text(
            '\$${totalBalance.toStringAsFixed(2)}',
            style: const TextStyle(
              color: AppTheme.primaryBlack,
              fontSize: 36,
              fontWeight: FontWeight.w800,
              letterSpacing: -0.5,
            ),
          ),

          const SizedBox(height: 24),

          // Barre de progression
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Dépenses du Mois',
                    style: TextStyle(
                      color: AppTheme.primaryBlack,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  Text(
                    '$expensePercentage%',
                    style: TextStyle(
                      color: AppTheme.primaryBlack,
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              LinearPercentIndicator(
                lineHeight: 12,
                percent: expensePercentage / 100,
                backgroundColor: Colors.black.withOpacity(0.2),
                progressColor: expensePercentage > 70
                    ? AppTheme.errorColor
                    : AppTheme.primaryBlack,
                barRadius: const Radius.circular(6),
              ),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    '\$${totalExpense.toStringAsFixed(2)}',
                    style: TextStyle(
                      color: AppTheme.primaryBlack,
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Text(
                    'Objectif: \$${monthlyBudget.toStringAsFixed(2)}',
                    style: TextStyle(
                      color: AppTheme.primaryBlack.withOpacity(0.7),
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ],
          ),

          const SizedBox(height: 16),

          // Message d'encouragement
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.2),
              borderRadius: BorderRadius.circular(AppTheme.borderRadiusMedium),
            ),
            child: Row(
              children: [
                Icon(
                  Icons.check_circle,
                  color: AppTheme.primaryBlack,
                  size: 18,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    '$expensePercentage% de vos dépenses, c\'est bien. Continuez comme ça !',
                    style: TextStyle(
                      color: AppTheme.primaryBlack,
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
