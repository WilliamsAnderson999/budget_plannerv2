import 'package:flutter/material.dart';
import 'package:budget_manager/theme/app_theme.dart';
import 'package:budget_manager/screens/security_pin_screen.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final _emailController = TextEditingController();
  bool _isLoading = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.primaryBlack,
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 80),

              // Bouton retour
              IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () => Navigator.pop(context),
                color: AppTheme.accentGold,
              ),

              const SizedBox(height: 20),

              // Titre
              Text(
                'Mot de passe oublié',
                style: Theme.of(context).textTheme.displayMedium,
              ),
              const SizedBox(height: 12),
              Text(
                'Réinitialisez votre mot de passe en quelques étapes simples',
                style: Theme.of(context).textTheme.titleSmall,
              ),

              const SizedBox(height: 40),

              // Illustration
              Container(
                height: 200,
                decoration: BoxDecoration(
                  color: AppTheme.surfaceBlack,
                  borderRadius:
                      BorderRadius.circular(AppTheme.borderRadiusLarge),
                ),
                child: Center(
                  child: Icon(
                    Icons.lock_reset_outlined,
                    size: 80,
                    color: AppTheme.accentBronze,
                  ),
                ),
              ),

              const SizedBox(height: 40),

              // Description
              Text(
                'Entrez l\'adresse email associée à votre compte. Nous vous enverrons un code de vérification pour réinitialiser votre mot de passe.',
                style: Theme.of(context).textTheme.bodyLarge!.copyWith(
                      color: AppTheme.textSecondary,
                      height: 1.6,
                    ),
              ),

              const SizedBox(height: 32),

              // Champ email
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Adresse email',
                    style: Theme.of(context).textTheme.titleSmall,
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _emailController,
                    decoration: InputDecoration(
                      hintText: 'example@example.com',
                      prefixIcon: Icon(Icons.email_outlined,
                          color: AppTheme.textSecondary),
                    ),
                    style: Theme.of(context).textTheme.bodyLarge,
                    keyboardType: TextInputType.emailAddress,
                  ),
                ],
              ),

              const SizedBox(height: 40),

              // Bouton de réinitialisation
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _resetPassword,
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 18),
                    shape: RoundedRectangleBorder(
                      borderRadius:
                          BorderRadius.circular(AppTheme.borderRadiusMedium),
                    ),
                  ),
                  child: _isLoading
                      ? const SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            valueColor: AlwaysStoppedAnimation<Color>(
                                AppTheme.primaryBlack),
                          ),
                        )
                      : Text(
                          'Envoyer le code de réinitialisation',
                          style: Theme.of(context).textTheme.labelLarge,
                        ),
                ),
              ),

              const SizedBox(height: 24),

              // Lien de connexion
              Center(
                child: GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Text.rich(
                    TextSpan(
                      text: 'Revenir à la ',
                      style: Theme.of(context).textTheme.bodyMedium,
                      children: [
                        TextSpan(
                          text: 'connexion',
                          style: TextStyle(
                            color: AppTheme.accentGold,
                            fontWeight: FontWeight.w600,
                            decoration: TextDecoration.underline,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 60),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _resetPassword() async {
    if (_emailController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Veuillez entrer votre adresse email',
            style: TextStyle(color: AppTheme.textPrimary),
          ),
          backgroundColor: AppTheme.errorColor,
        ),
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    // Simuler un délai d'envoi
    await Future.delayed(const Duration(seconds: 2));

    setState(() {
      _isLoading = false;
    });

    // Naviguer vers l'écran de code PIN
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => SecurityPinScreen(
          email: _emailController.text,
          isPasswordReset: true,
        ),
      ),
    );
  }

  @override
  void dispose() {
    _emailController.dispose();
    super.dispose();
  }
}
