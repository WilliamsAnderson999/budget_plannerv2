import 'package:flutter/material.dart';
import 'package:budget_manager/widgets/transaction_item.dart';
import 'package:budget_manager/theme/app_theme.dart';
import 'package:provider/provider.dart';
import 'package:budget_manager/services/auth_service.dart';
import 'package:budget_manager/services/transaction_service.dart';
import 'package:budget_manager/models/transaction.dart' as budget_transaction;

class TransactionsScreen extends StatefulWidget {
  const TransactionsScreen({super.key});

  @override
  State<TransactionsScreen> createState() => _TransactionsScreenState();
}

class _TransactionsScreenState extends State<TransactionsScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final authService = Provider.of<AuthService>(context, listen: false);
      final transactionService =
          Provider.of<TransactionService>(context, listen: false);
      if (authService.currentUser != null) {
        transactionService.fetchTransactions(authService.currentUser!.uid);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isSmallScreen = screenWidth < 600;

    final authService = Provider.of<AuthService>(context);

    // Check if user is logged in
    if (authService.currentUser == null) {
      return Scaffold(
        backgroundColor: AppTheme.primaryBlack,
        body: const Center(child: Text('User not logged in')),
      );
    }

    return Scaffold(
      backgroundColor: AppTheme.primaryBlack,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            pinned: true,
            floating: true,
            backgroundColor: AppTheme.surfaceBlack,
            title: Text(
              'Transactions',
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                    fontSize: isSmallScreen ? 20 : 24,
                  ),
            ),
            actions: [
              IconButton(
                icon: const Icon(Icons.filter_list),
                onPressed: () {},
                color: AppTheme.accentGold,
              ),
              IconButton(
                icon: const Icon(Icons.sort),
                onPressed: () {},
                color: AppTheme.accentGold,
              ),
            ],
          ),
          SliverToBoxAdapter(
            child: Consumer<TransactionService>(
              builder: (context, transactionService, child) => Padding(
                padding: EdgeInsets.all(isSmallScreen ? 12 : 16.0),
                child: Column(
                  children: [
                    _buildQuickFilters(context),
                    SizedBox(height: isSmallScreen ? 16 : 24),
                    ..._buildTransactionList(
                        context, authService, transactionService),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickFilters(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isSmallScreen = screenWidth < 600;

    final filters = [
      {'label': 'Tout', 'active': true},
      {'label': 'Revenus', 'active': true},
      {'label': 'Dépenses', 'active': true},
      {'label': 'Cette Semaine', 'active': true},
      {'label': 'Ce Mois ', 'active': true}
    ];

    return SizedBox(
      height: isSmallScreen ? 35 : 40,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: filters.length,
        itemBuilder: (context, index) {
          final filter = filters[index];
          return Container(
            margin: EdgeInsets.only(right: isSmallScreen ? 6 : 8),
            child: FilterChip(
              label: Text(
                filter['label'] as String,
                style: TextStyle(fontSize: isSmallScreen ? 12 : 14),
              ),
              selected: filter['active'] as bool,
              onSelected: (selected) {},
              selectedColor: AppTheme.accentBronze,
              labelStyle: TextStyle(
                color: filter['active'] as bool
                    ? AppTheme.primaryBlack
                    : AppTheme.textPrimary,
                fontSize: isSmallScreen ? 12 : 14,
              ),
              backgroundColor: AppTheme.cardBlack,
            ),
          );
        },
      ),
    );
  }

  List<Widget> _buildTransactionList(BuildContext context,
      AuthService authService, TransactionService transactionService) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isSmallScreen = screenWidth < 600;

    // Use real transactions from the service
    final allTransactions = transactionService.transactions;

    // Sort by date descending
    allTransactions.sort((a, b) => b.date.compareTo(a.date));

    // Group by month
    final groupedTransactions =
        <String, List<budget_transaction.Transaction>>{};
    for (var transaction in allTransactions) {
      final month = '${transaction.date.month} ${transaction.date.year}';
      groupedTransactions.putIfAbsent(month, () => []);
      groupedTransactions[month]!.add(transaction);
    }

    return groupedTransactions.entries.map((entry) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.symmetric(vertical: isSmallScreen ? 12 : 16),
            child: Text(
              entry.key,
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontSize: isSmallScreen ? 16 : 18,
                  ),
            ),
          ),
          ...entry.value.map((transaction) {
            return Padding(
              padding: EdgeInsets.only(bottom: isSmallScreen ? 8 : 12),
              child: TransactionItem(
                title: transaction.title,
                subtitle:
                    '${transaction.date.hour}:${transaction.date.minute.toString().padLeft(2, '0')} - ${transaction.date.day} ${transaction.date.month} | ${transaction.category}',
                category: transaction.category,
                amount: transaction.amount,
                isExpense: transaction.isExpense,
                icon: _getIconForCategory(transaction.category),
                onTap: () {
                  // View transaction details
                },
              ),
            );
          }),
        ],
      );
    }).toList();
  }

  IconData _getIconForCategory(String category) {
    switch (category.toLowerCase()) {
      case 'salaire':
      case 'income':
        return Icons.account_balance_wallet_outlined;
      case 'alimentation':
      case 'food':
        return Icons.shopping_cart_outlined;
      case 'loyer':
      case 'rent':
        return Icons.home_outlined;
      case 'transport':
        return Icons.directions_car_outlined;
      case 'restaurant':
        return Icons.restaurant_outlined;
      case 'travail':
      case 'work':
        return Icons.computer_outlined;
      case 'divertissement':
      case 'entertainment':
        return Icons.movie_outlined;
      default:
        return Icons.attach_money_outlined;
    }
  }
}
