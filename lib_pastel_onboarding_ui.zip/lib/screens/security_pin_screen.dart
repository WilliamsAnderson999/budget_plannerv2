import 'package:flutter/material.dart';
import 'package:budget_manager/theme/app_theme.dart';
import 'package:budget_manager/theme/auth_palette.dart';
import 'package:budget_manager/widgets/auth/auth_background.dart';
import 'package:budget_manager/widgets/auth/soft_card.dart';
import 'package:budget_manager/widgets/pin_keypad.dart';
import 'package:budget_manager/screens/new_password_screen.dart';
import 'package:budget_manager/app.dart';

class SecurityPinScreen extends StatefulWidget {
  final String? email;
  final bool isPasswordReset;

  const SecurityPinScreen({
    super.key,
    this.email,
    this.isPasswordReset = false,
  });

  @override
  State<SecurityPinScreen> createState() => _SecurityPinScreenState();
}

class _SecurityPinScreenState extends State<SecurityPinScreen> {
  String _pin = '';
  final int _pinLength = 6;
  final int _attempts = 3;
  bool _isError = false;

  @override
  Widget build(BuildContext context) {
    return AuthBackground(
      gradient: AuthPalette.onboardingGradient(4),
      child: Scaffold(
        backgroundColor: Colors.transparent,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 40),

              // Titre
              Text(
                widget.isPasswordReset
                    ? 'Code de vérification'
                    : 'Code PIN de sécurité',
                style: Theme.of(context).textTheme.displayMedium,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 12),

              // Description
              Text(
                widget.isPasswordReset
                    ? 'Entrez le code à 6 chiffres envoyé à\n${widget.email ?? "votre email"}'
                    : 'Créez un code PIN à 6 chiffres pour sécuriser votre compte',
                style: Theme.of(context).textTheme.titleSmall,
                textAlign: TextAlign.center,
              ),

              const SizedBox(height: 40),

              // Indicateur de tentatives
              if (_attempts < 3 && !widget.isPasswordReset)
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                    // ignore: deprecated_member_use
                    color: AppTheme.errorColor.withOpacity(0.15),
                    borderRadius:
                        BorderRadius.circular(AppTheme.borderRadiusMedium),
                    border:
                        // ignore: deprecated_member_use
                        Border.all(color: AppTheme.errorColor.withOpacity(0.3)),
                  ),
                  child: Text(
                    '$_attempts tentatives restantes',
                    style: TextStyle(
                      color: AppTheme.errorColor,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),

              const SizedBox(height: 40),

              // Indicateur de code PIN
              _buildPinIndicator(),

              const SizedBox(height: 40),

              // Message d'erreur
              if (_isError)
                Padding(
                  padding: const EdgeInsets.only(bottom: 20),
                  child: Text(
                    widget.isPasswordReset
                        ? 'Code incorrect. Veuillez réessayer.'
                        : 'Code PIN incorrect',
                    style: TextStyle(
                      color: AppTheme.errorColor,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),

              // Clavier numérique
              Expanded(
                child: PinKeypad(
                  onNumberPressed: _onNumberPressed,
                  onDeletePressed: _onDeletePressed,
                  onBiometricPressed:
                      widget.isPasswordReset ? null : _onBiometricPressed,
                ),
              ),

              const SizedBox(height: 20),

              // Bouton de réenvoi
              if (widget.isPasswordReset)
                TextButton(
                  onPressed: _resendCode,
                  child: Text(
                    'Renvoyer le code',
                    style: TextStyle(
                      color: AppTheme.accentGold,
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),

              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    ),
    );
  }

  Widget _buildPinIndicator() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(_pinLength, (index) {
        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 8),
          width: 16,
          height: 16,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: index < _pin.length
                ? (_isError ? AppTheme.errorColor : AppTheme.accentGold)
                : AppTheme.surfaceBlack,
            border: Border.all(
              color: index < _pin.length
                  ? Colors.transparent
                  // ignore: deprecated_member_use
                  : AppTheme.textSecondary.withOpacity(0.3),
              width: 2,
            ),
          ),
        );
      }),
    );
  }

  void _onNumberPressed(String number) {
    if (_pin.length < _pinLength) {
      setState(() {
        _pin += number;
        _isError = false;
      });

      if (_pin.length == _pinLength) {
        _verifyPin();
      }
    }
  }

  void _onDeletePressed() {
    if (_pin.isNotEmpty) {
      setState(() {
        _pin = _pin.substring(0, _pin.length - 1);
        _isError = false;
      });
    }
  }

  void _onBiometricPressed() {
    // Logique d'authentification biométrique
  }

  Future<void> _verifyPin() async {
    // Simuler une vérification
    await Future.delayed(const Duration(milliseconds: 500));

    if (widget.isPasswordReset) {
      // Pour la réinitialisation, vérifier le code
      if (_pin == '123456') {
        // Code de test
        Navigator.pushReplacement(
          // ignore: use_build_context_synchronously
          context,
          MaterialPageRoute(
            builder: (context) => const NewPasswordScreen(),
          ),
        );
      } else {
        setState(() {
          _isError = true;
          _pin = '';
        });
      }
    } else {
      // Pour la création de PIN
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Code PIN créé avec succès !',
            style: TextStyle(color: AppTheme.textPrimary),
          ),
          backgroundColor: AppTheme.successColor,
        ),
      );
      await Future.delayed(const Duration(seconds: 1));
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) => const App()),
        (route) => false,
      );
    }
  }

  void _resendCode() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Code envoyé à ${widget.email ?? "votre email"}',
          style: TextStyle(color: AppTheme.textPrimary),
        ),
        backgroundColor: AppTheme.successColor,
      ),
    );
  }
}
