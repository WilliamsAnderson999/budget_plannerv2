import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:budget_manager/services/ai_service.dart';
import 'package:budget_manager/services/transaction_service.dart';
import 'package:budget_manager/services/firestore_service.dart';
import 'package:budget_manager/services/auth_service.dart';
import 'package:budget_manager/models/goal.dart';
import 'package:budget_manager/theme/app_theme.dart';

class AIChatDialog extends StatefulWidget {
  const AIChatDialog({super.key});

  @override
  State<AIChatDialog> createState() => _AIChatDialogState();
}

class _AIChatDialogState extends State<AIChatDialog> {
  final TextEditingController _messageController = TextEditingController();
  final List<Map<String, String>> _messages = [];
  final AIService _aiService = AIService();
  bool _isLoading = false;

  List<Goal> _goals = [];

  @override
  void initState() {
    super.initState();
    _loadGoals();
    _addWelcomeMessage();
  }

  void _loadGoals() async {
    final authService = Provider.of<AuthService>(context, listen: false);
    final firestoreService =
        Provider.of<FirestoreService>(context, listen: false);
    final userId = authService.currentUser!.uid;
    final goals = await firestoreService.getGoals(userId);
    setState(() {
      _goals = goals;
    });
  }

  void _addWelcomeMessage() {
    _messages.add({
      'sender': 'AI',
      'message':
          'Bonjour ! Je suis votre assistant financier IA. Comment puis-je vous aider aujourd\'hui ?'
    });
  }

  void _sendMessage(String message) async {
    if (message.trim().isEmpty) return;

    setState(() {
      _messages.add({'sender': 'User', 'message': message});
      _isLoading = true;
    });

    _messageController.clear();

    final transactionService =
        Provider.of<TransactionService>(context, listen: false);
    final transactions = transactionService.transactions;

    try {
      final response =
          await _aiService.chatWithAI(message, transactions, _goals);
      setState(() {
        _messages.add({'sender': 'AI', 'message': response});
      });
    } catch (e) {
      setState(() {
        _messages.add(
            {'sender': 'AI', 'message': 'Désolé, une erreur s\'est produite.'});
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _sendPredefinedMessage(String message) {
    _sendMessage(message);
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: AppTheme.cardBlack,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppTheme.borderRadiusLarge),
      ),
      child: Container(
        width: MediaQuery.of(context).size.width * 0.9,
        height: MediaQuery.of(context).size.height * 0.8,
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                const Icon(Icons.smart_toy, color: AppTheme.accentGold),
                const SizedBox(width: 8),
                Text(
                  'Assistant IA Financier',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const Spacer(),
                IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: () => Navigator.of(context).pop(),
                ),
              ],
            ),
            const Divider(),
            // Predefined messages
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                ElevatedButton(
                  onPressed: () => _sendPredefinedMessage(
                      'Fais-moi une prédiction sur mes dépenses du mois prochain basée sur mes dépenses actuelles.'),
                  child: const Text('Prédiction dépenses'),
                ),
                ElevatedButton(
                  onPressed: () => _sendPredefinedMessage(
                      'Aide-moi à atteindre mes objectifs financiers.'),
                  child: const Text('Atteindre objectifs'),
                ),
                ElevatedButton(
                  onPressed: () => _sendPredefinedMessage(
                      'Donne-moi des conseils pour investir.'),
                  child: const Text('Conseils investissement'),
                ),
                ElevatedButton(
                  onPressed: () => _sendPredefinedMessage(
                      'Analyse mes habitudes de dépenses.'),
                  child: const Text('Analyser dépenses'),
                ),
              ],
            ),
            const Divider(),
            // Chat messages
            Expanded(
              child: ListView.builder(
                itemCount: _messages.length,
                itemBuilder: (context, index) {
                  final message = _messages[index];
                  final isUser = message['sender'] == 'User';
                  return Align(
                    alignment:
                        isUser ? Alignment.centerRight : Alignment.centerLeft,
                    child: Container(
                      margin: const EdgeInsets.symmetric(vertical: 4),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: isUser
                            ? AppTheme.accentBronze
                            : AppTheme.surfaceBlack,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        message['message']!,
                        style: TextStyle(
                            color: isUser ? Colors.white : Colors.white70),
                      ),
                    ),
                  );
                },
              ),
            ),
            if (_isLoading)
              const Padding(
                padding: EdgeInsets.all(8.0),
                child: CircularProgressIndicator(),
              ),
            // Input field
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _messageController,
                    decoration: const InputDecoration(
                      hintText: 'Tapez votre message...',
                      border: OutlineInputBorder(),
                    ),
                    onSubmitted: _sendMessage,
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.send),
                  onPressed: () => _sendMessage(_messageController.text),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
